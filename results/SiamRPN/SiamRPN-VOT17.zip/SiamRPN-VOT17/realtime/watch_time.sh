for d in `ls`
do
    if [ ! -d $d ]; then
        break
    fi
    echo $d
    cat $d/*_time.txt | sort | grep 0\\. | tail -n1
done
